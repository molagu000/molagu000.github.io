<!--@include: ./foo.md-->

### After Foo

<!--@include: ./subfolder/inside-subfolder.md-->
