# Foo

This is before region

<!-- #region snippet -->
## Region

This is a region
<!-- #endregion snippet -->

This is after region
