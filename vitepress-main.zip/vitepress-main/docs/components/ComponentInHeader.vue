<template>
  <span>&#x26A1;</span>
</template>
