// #region snippet
function foo() {
  // ..
}
// #endregion snippet

export default foo
