<template>
  <div class="VPPage">
    <slot name="page-top" />
    <Content />
    <slot name="page-bottom" />
  </div>
</template>
