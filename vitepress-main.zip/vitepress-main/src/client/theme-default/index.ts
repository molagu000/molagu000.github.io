import './styles/fonts.css'

export * from './without-fonts'
export { default as default } from './without-fonts'
